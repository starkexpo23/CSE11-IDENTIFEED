package com.example.identifeed.ui.profile

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QueryDocumentSnapshot

class ProfileViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()

    private val _user = MutableLiveData<DocumentSnapshot>().apply {
        db.collection("users").document(FirebaseAuth.getInstance().uid.toString())
            .get()
            .addOnSuccessListener { result ->
                value = result
            }
            .addOnFailureListener { exception ->
                value = null
            }
    }
    val user: LiveData<DocumentSnapshot> = _user

}