package com.example.identifeed.ui.information

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot

class InformationViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()

    private var _food = MutableLiveData<QuerySnapshot>()

    fun getFood(label: String) {
        db.collection("foods").whereEqualTo("name", label)
            .get()
            .addOnSuccessListener { result ->
                _food.postValue(result)
            }
            .addOnFailureListener { exception ->
                _food.postValue(null)
            }
    }

    val food: LiveData<QuerySnapshot> = _food

}