package com.example.identifeed.ui.admin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.identifeed.R
import com.example.identifeed.data.Food
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_admin_edit.*

class AdminEditActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_edit)

        //Get food extras passed from previous activity then display data on edittext
        val food: Food? = intent.extras?.getParcelable("food")

        if (food != null) {
            Glide.with(this)
                .load(food.image)
                .apply(RequestOptions.circleCropTransform())
                .into(image)

            name.setText(food.name)
            description.setText(food.description)
            calorieCount.setText(food.calorie_count)
            saturateFat.setText(food.saturated_fat)
            transFat.setText(food.trans_fat)
            cholesterol.setText(food.cholesterol)
            sodium.setText(food.sodium)
            dietaryFiber.setText(food.dietary_fiber)
            totalSugars.setText(food.total_sugars)
            protein.setText(food.protein)
            calcium.setText(food.calcium)
            iron.setText(food.iron)
            potassium.setText(food.potassium)
            healthBenefits.setText(food.health_benefits)
            carbs.setText(food.carbs)
            fat.setText(food.fat)
            polyunsaturated.setText(food.polyunsaturated)
            monounsaturated.setText(food.monounsaturated)
            vitaminA.setText(food.vitamin_a)
            vitaminC.setText(food.vitamin_c)
        }

        back.setOnClickListener {
            startActivity(Intent(this@AdminEditActivity, AdminActivity::class.java))
            finish()
        }

        save.setOnClickListener {
            if (food != null) {
                updateUserInformation(food.name)
            }
        }
    }

    override fun onBackPressed() {

    }

    //upload data to firebase database
    private fun updateUserInformation(nameString: String) {
        val db = FirebaseFirestore.getInstance()

        val updates = hashMapOf<String, Any>(
            "name" to name.text.toString(),
            "description" to description.text.toString(),
            "saturated_fat" to saturateFat.text.toString(),
            "trans_fat" to transFat.text.toString(),
            "cholesterol" to cholesterol.text.toString(),
            "sodium" to sodium.text.toString(),
            "dietary_fiber" to dietaryFiber.text.toString(),
            "total_sugars" to totalSugars.text.toString(),
            "protein" to protein.text.toString(),
            "calcium" to calcium.text.toString(),
            "iron" to iron.text.toString(),
            "potassium" to potassium.text.toString(),
            "calorie_count" to calorieCount.text.toString(),
            "health_benefits" to healthBenefits.text.toString(),
            "carbs" to carbs.text.toString(),
            "fat" to fat.text.toString(),
            "polyunsaturated" to polyunsaturated.text.toString(),
            "monounsaturated" to monounsaturated.text.toString(),
            "vitamin_a" to vitaminA.text.toString(),
            "vitamin_c" to vitaminC.text.toString()
        )

        db.collection("foods").whereEqualTo("name", nameString).get()
            .addOnSuccessListener {
                it.forEach { result ->
                val food = db.collection("foods").document(result.id)
                food
                    .update(updates)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Food information successfully updated!", Toast.LENGTH_SHORT).show()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this, "Food information update failed!", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Food information update failed!", Toast.LENGTH_SHORT).show()
            }
    }

}
