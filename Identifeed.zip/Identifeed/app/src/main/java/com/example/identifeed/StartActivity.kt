package com.example.identifeed

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_start.*

class StartActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start)

        //Start activity for display, let user choose if register or login and goto corresponding activity
        login.setOnClickListener {
            startActivity(Intent(this@StartActivity, LoginActivity::class.java))
        }
        start.setOnClickListener {
            startActivity(Intent(this@StartActivity, RegistrationActivity::class.java))
        }
    }

    override fun onBackPressed() {

    }
}
