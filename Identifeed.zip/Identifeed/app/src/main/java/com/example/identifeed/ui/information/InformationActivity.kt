package com.example.identifeed.ui.information

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.identifeed.R
import com.example.identifeed.ViewModelFactory
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import kotlinx.android.synthetic.main.activity_information.*

class InformationActivity : AppCompatActivity() {

    //Information activity
    //get label passed from home activity this label was taken from the labeler object
    //search the databse for an object with that label for example:
    //label is adobo, pass adobo to this activity then scrape DB for foods named adobo

    private lateinit var viewModel: InformationViewModel
    private var meal: HashMap<String, String> = HashMap()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_information)

        val db = FirebaseFirestore.getInstance()
        setUpViewModel()

        val label = intent.getStringExtra("label")
        if (label != null) {
            setUpObservers(label)
        }

        back.setOnClickListener {
            onBackPressed()
        }
        save.setOnClickListener {
            uploadMeal(db, meal)
        }

        serving.setText("1")
        serving.addTextChangedListener {
            //Multiply amounts with amount of servings
            if (serving.text.toString() != "") {

                calories.text = (serving.text.toString().toInt() * meal.get("calorie_count").toString().toDouble()).toString()
                carbs.text = (serving.text.toString().toInt() * meal.get("carbs").toString().toDouble()).toString()
                dietaryFiber.text = (serving.text.toString().toInt() * meal.get("dietary_fiber").toString().toDouble()).toString()
                totalSugars.text = (serving.text.toString().toInt() * meal.get("total_sugars").toString().toDouble()).toString()
                fat.text = (serving.text.toString().toInt() * meal.get("fat").toString().toDouble()).toString()
                saturateFat.text = (serving.text.toString().toInt() * meal.get("saturated_fat").toString().toDouble()).toString()
                polyunsaturated.text = (serving.text.toString().toInt() * meal.get("polyunsaturated").toString().toDouble()).toString()
                monounsaturated.text = (serving.text.toString().toInt() * meal.get("monounsaturated").toString().toDouble()).toString()
                transFat.text = (serving.text.toString().toInt() * meal.get("trans_fat").toString().toDouble()).toString()
                protein.text = (serving.text.toString().toInt() * meal.get("protein").toString().toDouble()).toString()
                sodium.text = (serving.text.toString().toInt() * meal.get("sodium").toString().toDouble()).toString()
                potassium.text = (serving.text.toString().toInt() * meal.get("potassium").toString().toDouble()).toString()
                cholesterol.text = (serving.text.toString().toInt() * meal.get("cholesterol").toString().toDouble()).toString()
                vitaminA.text = (serving.text.toString().toInt() * meal.get("vitamin_a").toString().toDouble()).toString()
                vitaminC.text = (serving.text.toString().toInt() * meal.get("vitamin_c").toString().toDouble()).toString()
                calcium.text = (serving.text.toString().toInt() * meal.get("calcium").toString().toDouble()).toString()
                iron.text = (serving.text.toString().toInt() * meal.get("iron").toString().toDouble()).toString()

            }
        }
    }

    private fun setUpViewModel() {
        viewModel = ViewModelProvider(
            this,
            ViewModelFactory()
        ).get(InformationViewModel::class.java)
    }

    private fun setUpObservers(label: String) {
        viewModel.getFood(label)
        viewModel.food.observe(this, Observer {
            if (it != null) {
                for (document in it) {
                    meal["calorie_count"] = document.get("calorie_count").toString()
                    meal["created_at"] = (System.currentTimeMillis() / 1000).toString()
                    meal["description"] = document.get("description").toString()
                    meal["image"] = document.get("image").toString()
                    meal["name"] = document.get("name").toString()
                    meal["health_benefits"] = document.get("health_benefits").toString()
                    meal["user_id"] = FirebaseAuth.getInstance().uid.toString()
                    meal["carbs"] = document.get("carbs").toString()
                    meal["dietary_fiber"] = document.get("dietary_fiber").toString()
                    meal["total_sugars"] = document.get("total_sugars").toString()
                    meal["fat"] = document.get("fat").toString()
                    meal["saturated_fat"] = document.get("saturated_fat").toString()
                    meal["polyunsaturated"] = document.get("polyunsaturated").toString()
                    meal["monounsaturated"] = document.get("monounsaturated").toString()
                    meal["trans_fat"] = document.get("trans_fat").toString()
                    meal["protein"] = document.get("protein").toString()
                    meal["sodium"] = document.get("sodium").toString()
                    meal["potassium"] = document.get("potassium").toString()
                    meal["cholesterol"] = document.get("cholesterol").toString()
                    meal["vitamin_a"] = document.get("vitamin_a").toString()
                    meal["vitamin_c"] = document.get("vitamin_c").toString()
                    meal["calcium"] = document.get("calcium").toString()
                    meal["iron"] = document.get("iron").toString()
                }
                updateUI(it)
            }
         })
    }

    private fun updateUI(documents: QuerySnapshot) {
        for (document in documents) {
            Glide.with(this@InformationActivity)
                .load(document.get("image").toString())
                .apply(RequestOptions.circleCropTransform())
                .into(image)
            name.text = document.get("name").toString()
            description.text = document.get("description").toString()
            calories.text = document.get("calorie_count").toString()
            healthBenefits.text = document.get("health_benefits").toString()
            carbs.text = document.get("carbs").toString()
            dietaryFiber.text = document.get("dietary_fiber").toString()
            totalSugars.text = document.get("total_sugars").toString()
            fat.text = document.get("fat").toString()
            saturateFat.text = document.get("saturated_fat").toString()
            polyunsaturated.text = document.get("polyunsaturated").toString()
            monounsaturated.text = document.get("monounsaturated").toString()
            transFat.text = document.get("trans_fat").toString()
            protein.text = document.get("protein").toString()
            sodium.text = document.get("sodium").toString()
            potassium.text = document.get("potassium").toString()
            cholesterol.text = document.get("cholesterol").toString()
            vitaminA.text = document.get("vitamin_a").toString()
            vitaminC.text = document.get("vitamin_c").toString()
            calcium.text = document.get("calcium").toString()
            iron.text = document.get("iron").toString()
        }
    }

    //Upload meal to meals DB to track previous meals eaten
    private fun uploadMeal(db: FirebaseFirestore, meal: HashMap<String, String>) {
        if (serving.text.toString() != "") {

            val calorie = serving.text.toString().toInt() * meal.get("calorie_count").toString().toDouble()
            meal["calorie_count"] = calorie.toString()

            val carbs = serving.text.toString().toInt() * meal.get("carbs").toString().toDouble()
            meal["carbs"] = carbs.toString()

            val dietary_fiber = serving.text.toString().toInt() * meal.get("dietary_fiber").toString().toDouble()
            meal["dietary_fiber"] = dietary_fiber.toString()

            val total_sugars = serving.text.toString().toInt() * meal.get("total_sugars").toString().toDouble()
            meal["total_sugars"] = total_sugars.toString()

            val fat = serving.text.toString().toInt() * meal.get("fat").toString().toDouble()
            meal["fat"] = fat.toString()

            val saturated_fat = serving.text.toString().toInt() * meal.get("saturated_fat").toString().toDouble()
            meal["saturated_fat"] = saturated_fat.toString()

            val polyunsaturated = serving.text.toString().toInt() * meal.get("polyunsaturated").toString().toDouble()
            meal["polyunsaturated"] = polyunsaturated.toString()

            val monounsaturated = serving.text.toString().toInt() * meal.get("monounsaturated").toString().toDouble()
            meal["monounsaturated"] = monounsaturated.toString()

            val trans_fat = serving.text.toString().toInt() * meal.get("trans_fat").toString().toDouble()
            meal["trans_fat"] = trans_fat.toString()

            val protein = serving.text.toString().toInt() * meal.get("protein").toString().toDouble()
            meal["protein"] = protein.toString()

            val sodium = serving.text.toString().toInt() * meal.get("sodium").toString().toDouble()
            meal["sodium"] = sodium.toString()

            val potassium = serving.text.toString().toInt() * meal.get("potassium").toString().toDouble()
            meal["potassium"] = potassium.toString()

            val cholesterol = serving.text.toString().toInt() * meal.get("cholesterol").toString().toDouble()
            meal["cholesterol"] = cholesterol.toString()

            val vitamin_a = serving.text.toString().toInt() * meal.get("vitamin_a").toString().toDouble()
            meal["vitamin_a"] = vitamin_a.toString()

            val vitamin_c = serving.text.toString().toInt() * meal.get("vitamin_c").toString().toDouble()
            meal["vitamin_c"] = vitamin_c.toString()

            val calcium = serving.text.toString().toInt() * meal.get("calcium").toString().toDouble()
            meal["calcium"] = calcium.toString()

            val iron = serving.text.toString().toInt() * meal.get("iron").toString().toDouble()
            meal["iron"] = iron.toString()

        }

        val id = db.collection("meals").document().id
        db.collection("meals").document(id)
            .set(meal)
            .addOnSuccessListener {
                val intent = Intent()
                intent.putExtra("status", "success")
                setResult(Activity.RESULT_OK, intent)
                finish()
            }
            .addOnFailureListener {
                val intent = Intent()
                intent.putExtra("status", "failed")
                setResult(Activity.RESULT_CANCELED, intent)
                finish()
            }
    }

}
