package com.example.identifeed

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth


class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (checkIfAlreadyHavePermission()) {
            requestForSpecificPermission()
        }

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()
    }

    //Check if a user is logged in
    private fun isUserExistent(): Boolean {
        val currentUser = auth.currentUser
        return currentUser != null
    }

    //Start next activity if user have permissions and if user is logged in
    private fun startNextActivity(boolean: Boolean) {
        //goto start activity if user is not logged in, and home activity if user is logged in
        when(boolean) {
            true -> startActivity(Intent(this@MainActivity, HomeActivity::class.java))
            false -> startActivity(Intent(this@MainActivity, StartActivity::class.java))
        }
    }

    //Request for permissions which are not allowed and will not be able to run app
    private fun requestForSpecificPermission() {
        ActivityCompat.requestPermissions(
            this, arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA
            ), 101
        )
    }

    //Check if application already have the permissions needed to run the application
    private fun checkIfAlreadyHavePermission(): Boolean {
        val result = ContextCompat.checkSelfPermission(this, Manifest.permission.GET_ACCOUNTS)
        return result != PackageManager.PERMISSION_GRANTED
    }

    //Check permissions results
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (requestCode == 101) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                //PERMISSION GRANTED
                startNextActivity(isUserExistent())
            } else {
                //PERMISSION NOT GRANTED
                Toast.makeText(this@MainActivity, "Permissions denied!", Toast.LENGTH_SHORT).show()
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }
}
