package com.example.identifeed.ui.admin

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.identifeed.data.Food
import com.google.firebase.firestore.FirebaseFirestore

class AdminViewModel : ViewModel() {
    private val db = FirebaseFirestore.getInstance()

    private val _foods = MutableLiveData<List<Food>>().apply {
        db.collection("foods")
            .get()
            .addOnSuccessListener { result ->
                val list: ArrayList<Food> = ArrayList()
                for (document in result) {
                    list.add(document.toObject(Food::class.java))

                }
                value = result.toObjects(Food::class.java)
            }
            .addOnFailureListener { exception ->
                value = null
            }
    }
    val foods: LiveData<List<Food>> = _foods
}