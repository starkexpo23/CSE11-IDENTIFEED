package com.example.identifeed.ui.admin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.identifeed.R
import com.example.identifeed.StartActivity
import com.example.identifeed.ViewModelFactory
import com.example.identifeed.data.Food
import com.example.identifeed.ui.admin.adapter.FoodAdapter
import kotlinx.android.synthetic.main.activity_admin.*

class AdminActivity : AppCompatActivity() {

    //admin activity used for editing food data

    private lateinit var viewModel: AdminViewModel
    private lateinit var adapter: FoodAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        logout.setOnClickListener {
            startActivity(Intent(this@AdminActivity, StartActivity::class.java))
            finish()
        }

        //set up view model initialize view model
        setUpViewModel()
        //set up UI relate recycler view with adapter
        setUpUI()
        //Observe data inside the viewModels and update recyclerview on data changed
        setUpObservers()
    }

    private fun setUpViewModel() {
        viewModel = ViewModelProvider(
            this,
            ViewModelFactory()
        ).get(AdminViewModel::class.java)
    }

    private fun setUpUI() {
        recyclerView_foods.layoutManager = LinearLayoutManager(this)
        adapter = FoodAdapter()
        adapter.setOnItemClickListener(object: FoodAdapter.OnItemClickListener{
            override fun onItemClick(food: Food) {
                val intent = Intent(this@AdminActivity, AdminEditActivity::class.java)
                intent.putExtra("food", food)
                startActivity(intent)
            }
        })
        recyclerView_foods.adapter = adapter
    }

    private fun setUpObservers() {
        viewModel.foods.observe(this, Observer {
            retrieveFoods(it)
        })
    }

    private fun retrieveFoods(foods: List<Food>) {
        adapter.apply {
            adapter.submitList(foods)
            notifyDataSetChanged()
        }
    }

    override fun onBackPressed() {

    }
}
