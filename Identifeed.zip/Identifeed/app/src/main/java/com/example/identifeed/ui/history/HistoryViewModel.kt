package com.example.identifeed.ui.history

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.identifeed.data.History
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class HistoryViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()

    private val _history = MutableLiveData<List<History>>().apply {
        val list: ArrayList<History> = ArrayList()
        db.collection("meals").whereEqualTo("user_id", FirebaseAuth.getInstance().uid)
            .get()
            .addOnSuccessListener { result ->
                value = result.toObjects(History::class.java)
            }
            .addOnFailureListener { exception ->
                value = null
            }
    }
    val history: LiveData<List<History>> = _history

}