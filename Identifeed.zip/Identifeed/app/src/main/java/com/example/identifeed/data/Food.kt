package com.example.identifeed.data

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

//Food data class
@Parcelize
data class Food(
    var calorie_count: String = "",
    var description: String = "",
    var image: String = "",
    var name: String = "",
    var saturated_fat: String = "",
    var trans_fat: String = "",
    var cholesterol: String = "",
    var sodium: String = "",
    var dietary_fiber: String = "",
    var total_sugars: String = "",
    var protein: String = "",
    var calcium: String = "",
    var iron: String = "",
    var potassium: String = "",
    var health_benefits: String = "",
    var carbs: String = "",
    var fat: String = "",
    var polyunsaturated: String = "",
    var monounsaturated: String = "",
    var vitamin_a: String = "",
    var vitamin_c: String = ""
): Parcelable