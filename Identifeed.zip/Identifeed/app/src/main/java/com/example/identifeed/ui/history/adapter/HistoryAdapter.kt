package com.example.identifeed.ui.history.adapter

import android.content.Context
import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.identifeed.R
import com.example.identifeed.data.History
import kotlinx.android.synthetic.main.item_history.view.*
import java.util.*
import kotlin.collections.ArrayList

class HistoryAdapter : RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>() {

    //History adapter is for creating every item in the recycler view list: google creating recyclerview to learn more

    lateinit var context: Context
    private var items: List<History> = ArrayList()

    private var listener: OnItemClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): HistoryAdapter.HistoryViewHolder {
        context = parent.context
        return HistoryViewHolder(
            LayoutInflater.from(context).inflate(R.layout.item_history, parent, false)
        )
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: HistoryAdapter.HistoryViewHolder, position: Int) {
        holder.bind(items[position], context)
    }

    fun submitList(history: List<History>) {
        items = history
    }

    inner class HistoryViewHolder constructor(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            itemView.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    listener?.onItemClick(items[position])
                }
            }
        }

        private val image = itemView.image
        private val createdAt = itemView.textView_createdAt
        private val name = itemView.textView_name
        private val description = itemView.textView_description

        fun bind(history: History, context: Context) {
            Glide.with(context)
                .load(history.image)
                .apply(RequestOptions.circleCropTransform())
                .into(image)

            val epoch = history.created_at
            val millisecond = epoch.toLong() * 1000
            val dateString: String = DateFormat.format("MMMM dd, yyyy hh:mm", Date(millisecond)).toString()

            createdAt.text = dateString
            name.text = history.name
            description.text = history.description
        }
    }

    interface OnItemClickListener {
        fun onItemClick(history: History)
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        this.listener = listener
    }

}