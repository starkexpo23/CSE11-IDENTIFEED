package com.example.identifeed.data

//Meal data class
data class Meal(
    var image: String,
    var name: String,
    var description: String,
    var calorie_count: Double,
    var created_at: String
)