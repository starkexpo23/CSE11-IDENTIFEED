package com.example.identifeed.ui.profile

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.identifeed.R
import com.example.identifeed.StartActivity
import com.example.identifeed.ViewModelFactory
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.fragment_profile.*

class ProfileFragment : Fragment() {

    companion object {
        fun newInstance() = ProfileFragment()
    }

    private lateinit var viewModel: ProfileViewModel

    private lateinit var auth: FirebaseAuth

    lateinit var gender: String

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        val db = FirebaseFirestore.getInstance()

        auth = FirebaseAuth.getInstance()

        //Set up view model
        setUpViewModel(db)
        //Set up observers to watch database
        setUpObservers()

        logout.setOnClickListener {
            auth.signOut()
            startActivity(Intent(context, StartActivity::class.java))
        }

        save.setOnClickListener {
            updateUserInformation(db)
        }
    }

    private fun setUpViewModel(db: FirebaseFirestore) {
        viewModel = ViewModelProvider(
            this,
            ViewModelFactory()
        ).get(ProfileViewModel::class.java)
    }

    private fun setUpObservers() {
        viewModel.user.observe(viewLifecycleOwner, Observer {
            if (it != null) {
                name.setText(it.data?.get("name").toString())
                age.setText(it.data?.get("age").toString())
                height.setText(it.data?.get("height").toString())
                weight.setText(it.data?.get("weight").toString())
                gender = it.data?.get("gender").toString()
            }
        })
    }

    //Update user information on database
    private fun updateUserInformation(db: FirebaseFirestore) {
        val user = db.collection("users").document(auth.uid.toString())
        val updates = hashMapOf<String, Any>(
            "name" to name.text.toString(),
            "age" to age.text.toString(),
            "height" to height.text.toString(),
            "weight" to weight.text.toString(),
            "recommended_calorie" to getRecommendedCalorie(gender, age.text.toString().toDouble(), height.text.toString().toDouble(), weight.text.toString().toDouble())
        )
        user
            .update(updates)
            .addOnSuccessListener {
                Toast.makeText(context, "Profile successfully updated!", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(context, "Profile update failed!", Toast.LENGTH_SHORT).show()
            }
    }

    //compute recommended calorie when a profile value is changed
    private fun getRecommendedCalorie(gender: String, age: Double, height: Double, weight: Double): Double {
        if (gender == "Male") {
            return (10 * weight) + (6.25 * height) - (5 * age) + 5
        } else if (gender == "Female") {
            return (10 * weight) + (6.25 * height) - (5 * age) - 161
        }
        return 0.0
    }
}
