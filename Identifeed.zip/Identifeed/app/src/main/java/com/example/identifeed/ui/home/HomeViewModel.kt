package com.example.identifeed.ui.home

import android.text.format.DateUtils
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.identifeed.data.History
import com.example.identifeed.data.Meal
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.fragment_home.*

class HomeViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()

    private val _user = MutableLiveData<DocumentSnapshot>().apply {
        db.collection("users").document(FirebaseAuth.getInstance().uid.toString())
            .get()
            .addOnSuccessListener { result ->
                value = result
            }
            .addOnFailureListener { exception ->
                value = null
            }
    }
    val user: LiveData<DocumentSnapshot> = _user

    private val _calorieIntake = MutableLiveData<String>().apply {
        val meals = ArrayList<Meal>()
        db.collection("meals").whereEqualTo("user_id", FirebaseAuth.getInstance().uid)
            .get()
            .addOnSuccessListener { result ->
                for (document in result) {
                    if (DateUtils.isToday(document.get("created_at").toString().toLong() * 1000)) {
                        meals.add(Meal(
                            document.get("image").toString(),
                            document.get("name").toString(),
                            document.get("description").toString(),
                            document.get("calorie_count").toString().toDouble(),
                            document.get("created_at").toString()
                        ))
                    }
                }
                value = meals.sumByDouble { it.calorie_count }.toString()
            }
            .addOnFailureListener { exception ->
                value = null
            }
    }
    val calorieIntake: LiveData<String> = _calorieIntake

    private val _history = MutableLiveData<List<History>>().apply {
        val list: ArrayList<History> = ArrayList()
        db.collection("meals").whereEqualTo("user_id", FirebaseAuth.getInstance().uid)
            .get()
            .addOnSuccessListener { result ->
                value = result.toObjects(History::class.java)
            }
            .addOnFailureListener { exception ->
                value = null
            }
    }
    val history: LiveData<List<History>> = _history


    val dailyPercentage = _user.combineWith(_calorieIntake) { user, calorieIntake ->
        if (calorieIntake != null && user != null) {
            return@combineWith ((calorieIntake.toDouble().div(user.get("recommended_calorie").toString().toDouble())).times(100)).toInt()
        } else {
            return@combineWith 0
        }
    }

    private fun <T, K, R> LiveData<T>.combineWith(liveData: LiveData<K>, block: (T?, K?) -> R): LiveData<R> {
        val result = MediatorLiveData<R>()
        result.addSource(this) {
            result.value = block.invoke(this.value, liveData.value)
        }
        result.addSource(liveData) {
            result.value = block.invoke(this.value, liveData.value)
        }
        return result
    }

}