package com.example.identifeed.ui.home

import android.app.Activity.RESULT_OK
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.identifeed.HistoryInformationActivity
import com.example.identifeed.HomeActivity
import com.example.identifeed.R
import com.example.identifeed.ViewModelFactory
import com.example.identifeed.data.History
import com.example.identifeed.ui.history.adapter.HistoryAdapter
import com.example.identifeed.ui.information.InformationActivity
import com.github.lzyzsd.circleprogress.DonutProgress
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ml.vision.FirebaseVision
import com.google.firebase.ml.vision.automl.FirebaseAutoMLLocalModel
import com.google.firebase.ml.vision.common.FirebaseVisionImage
import com.google.firebase.ml.vision.label.FirebaseVisionImageLabeler
import com.google.firebase.ml.vision.label.FirebaseVisionOnDeviceAutoMLImageLabelerOptions
import kotlinx.android.synthetic.main.fragment_home.*
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.io.InputStream


class HomeFragment : Fragment() {

    companion object {
        fun newInstance() = HomeFragment()
    }

    // filename values for taking image
    private val FILE_NAME = "temp.jpg"
    // activity results to handle on activity results
    private val CAMERA_IMAGE_REQUEST = 3
    private val GALLERY_IMAGE_REQUEST = 6
    private val UPLOAD_MEAL_REQUEST = 9

    //declare firebase database
    lateinit var db: FirebaseFirestore

    //declare image labeler
    private lateinit var labeler: FirebaseVisionImageLabeler

    //declare viewmodel and adapter
    private lateinit var viewModel: HomeViewModel
    private lateinit var adapter: HistoryAdapter

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        //Camera take photo
        if (requestCode == CAMERA_IMAGE_REQUEST && resultCode == RESULT_OK) {
            try {
                val photoUri = FileProvider.getUriForFile(
                    requireContext(),
                    requireContext().applicationContext.packageName.toString() + ".provider",
                    getCameraFile()
                )
                val bitmap =
                    MediaStore.Images.Media.getBitmap(requireContext().contentResolver, photoUri)
                val image: FirebaseVisionImage = FirebaseVisionImage.fromBitmap(bitmap)
                //Convert photo uri to bitmap then bitmap to firebase vision image
                //This is preparing image for recognition
                //pass firebase vision image to get image label to process
                getImageLabel(image)
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
        //Take photo from gallery
        if (requestCode == GALLERY_IMAGE_REQUEST && resultCode == RESULT_OK) {
            try {
                val imageUri = data?.data
                val imageStream: InputStream? =
                    requireContext().contentResolver.openInputStream(imageUri!!)
                val selectedImage = BitmapFactory.decodeStream(imageStream)
                val image: FirebaseVisionImage = FirebaseVisionImage.fromBitmap(selectedImage)
                //Convert photo uri to bitmap then bitmap to firebase vision image
                //This is preparing image for recognition
                //pass firebase vision image to get image label to process
                getImageLabel(image)
            } catch (e: FileNotFoundException) {
                e.printStackTrace()
            }
        }
        //User came from food information activity refresh home when datas are changed
        if (requestCode == UPLOAD_MEAL_REQUEST && resultCode == RESULT_OK) {
            (context as HomeActivity).refreshHome()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        //Initialize firebase database instance
        db = FirebaseFirestore.getInstance()


        //set up view model initialize view model
        setUpViewModel()
        //Observe data inside the viewModels and update recyclerview on data changed
        setUpObservers()

        //Camera fab button take image from camera or get photo from gallery
        fab.setOnClickListener {
            val options = arrayOf("Take image using camera", "Select image from gallery")

            val builder = AlertDialog.Builder(context)
            builder.setTitle("Pick an action")
            builder.setItems(options) { _, which ->
                if (which == 0) {
                    startCamera()
                }
                if (which == 1) {
                    val photoPickerIntent = Intent(Intent.ACTION_PICK)
                    photoPickerIntent.type = "image/*"
                    startActivityForResult(photoPickerIntent, GALLERY_IMAGE_REQUEST)
                }
            }
            builder.show()
        }

        //Build the local model for image recognition using the downloaded assets from firebase autoML model that was created
        val localModel = FirebaseAutoMLLocalModel.Builder()
            .setAssetFilePath("manifest.json")
            .build()
        //Create a model labeler options with confidence threshold desired set to 0.5f == 50% confidence
        val options = FirebaseVisionOnDeviceAutoMLImageLabelerOptions.Builder(localModel)
            .setConfidenceThreshold(0.5f)
            .build()

        //Initialize labeler
        labeler = FirebaseVision.getInstance().getOnDeviceAutoMLImageLabeler(options)

        setUpUILastMeal()
    }

    private fun setUpViewModel() {
        viewModel = ViewModelProvider(
            this,
            ViewModelFactory()
        ).get(HomeViewModel::class.java)
    }

    private fun setUpObservers() {
        viewModel.user.observe(viewLifecycleOwner, Observer {
            if (it != null) {
                textView_recommended_calorie_intake.text = it.data?.get("recommended_calorie").toString()
            }
        })
        viewModel.calorieIntake.observe(viewLifecycleOwner, Observer {
            if (it != null) {
                textView_calorie_intake.text = it
            }
        })
        viewModel.dailyPercentage.observe(viewLifecycleOwner, Observer {
            context?.let { it1 ->
                if (it != null) {
                    updateDonut(donut_progress, it, it1)
                }
            }
        })
        viewModel.history.observe(viewLifecycleOwner, Observer {
            if (it != null) {
                retrieveLastMeal(it)
            }
        })
    }

    private fun startCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        val photoUri: Uri = FileProvider.getUriForFile(
            requireContext(),
            requireContext().applicationContext.packageName.toString() + ".provider",
            getCameraFile()
        )
        intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivityForResult(intent, CAMERA_IMAGE_REQUEST)
    }

    private fun getCameraFile(): File {
        val dir: File? = requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File(dir, FILE_NAME)
    }

    //Get image label and confidence of labels then get the highest confidence and post that as the image recognition label
    private fun getImageLabel(image: FirebaseVisionImage) {
        labeler.processImage(image)
            .addOnSuccessListener { labels ->
                val highestConfidenceLabel = labels.maxBy { it.confidence }
                val intent = Intent(context, InformationActivity::class.java)
                if (highestConfidenceLabel != null) {
                    //Start activity to food information and pass label
                    intent.putExtra("label", highestConfidenceLabel.text)
                    startActivityForResult(intent, UPLOAD_MEAL_REQUEST)
                } else {
                    Toast.makeText(context, "Cannot recognize image!", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
            }
    }

    //Creating donut progress bar UI
    private fun updateDonut(donut_progress: DonutProgress, percentage: Int, context: Context) {
        var progress = percentage
        if (progress >= 100) {
            progress = 100
        }
        if (progress >= 100) {
            donut_progress.finishedStrokeColor = ContextCompat.getColor(context, R.color.red)
            donut_progress.unfinishedStrokeColor = ContextCompat.getColor(context, R.color.bg_red)
            donut_progress.textColor = ContextCompat.getColor(context, R.color.red)
        } else {
            donut_progress.finishedStrokeColor = ContextCompat.getColor(context, R.color.green)
            donut_progress.unfinishedStrokeColor = ContextCompat.getColor(
                context,
                R.color.bg_green
            )
            donut_progress.textColor = ContextCompat.getColor(context, R.color.green)
        }
        if (progress != 0) {
            val finalProgress = progress
            object : CountDownTimer(2500, 10) {
                var x = 0f
                override fun onTick(millisUntilFinished: Long) {
                    if (!donut_progress.progress.equals(finalProgress.toFloat())) {
                        donut_progress.progress = x
                        x++
                    }
                }

                override fun onFinish() {}
            }.start()
        }
    }

    private fun setUpUILastMeal() {
        recyclerView_lastMeal.layoutManager = LinearLayoutManager(context)
        adapter = HistoryAdapter()
        adapter.setOnItemClickListener(object: HistoryAdapter.OnItemClickListener{
            override fun onItemClick(history: History) {
                val intent = Intent(context, HistoryInformationActivity::class.java)
                intent.putExtra("history", history)
                startActivity(intent)
            }
        })
        recyclerView_lastMeal.adapter = adapter
    }

    private fun retrieveLastMeal(history: List<History>) {
        if (history.isNotEmpty()) {
            val list: ArrayList<History> = ArrayList()
            list.add(history[0])
            adapter.apply {
                adapter.submitList(list)
                notifyDataSetChanged()
            }
        }
    }

    //Hello world

}
