package com.example.identifeed.ui.admin.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.identifeed.R
import com.example.identifeed.data.Food
import kotlinx.android.synthetic.main.item_food.view.*
import kotlin.collections.ArrayList

class FoodAdapter : RecyclerView.Adapter<FoodAdapter.FoodViewHolder>() {

    //Food adapter is for creating every item in the recycler view list: google creating recyclerview to learn more

    lateinit var context: Context
    private var items: List<Food> = ArrayList()

    private var listener: OnItemClickListener? = null

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): FoodAdapter.FoodViewHolder {
        context = parent.context
        return FoodViewHolder(
            LayoutInflater.from(context).inflate(R.layout.item_food, parent, false)
        )
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: FoodAdapter.FoodViewHolder, position: Int) {
        holder.bind(items[position], context)
    }

    fun submitList(foods: List<Food>) {
        items = foods
    }

    inner class FoodViewHolder constructor(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            itemView.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    listener?.onItemClick(items[position])
                }
            }
        }

        private val image = itemView.image
        private val name = itemView.textView_name
        private val description = itemView.textView_description

        fun bind(food: Food, context: Context) {
            Glide.with(context)
                .load(food.image)
                .apply(RequestOptions.circleCropTransform())
                .into(image)
            name.text = food.name
            description.text = food.description
        }
    }

    interface OnItemClickListener {
        fun onItemClick(food: Food)
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        this.listener = listener
    }

}