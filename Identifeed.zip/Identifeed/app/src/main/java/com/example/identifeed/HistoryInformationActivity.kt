package com.example.identifeed

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.identifeed.data.History
import kotlinx.android.synthetic.main.activity_history_information.*

class HistoryInformationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history_information)

        val food: History? = intent.extras?.getParcelable("history")

        //Get datas passed from intent extras and display to corresponding fields
        if (food != null) {
            Glide.with(this)
                .load(food.image)
                .apply(RequestOptions.circleCropTransform())
                .into(image)

            name.text = food.name
            description.text = food.description
            calories.text = food.calorie_count
            saturateFat.text = food.saturated_fat
            transFat.text = food.trans_fat
            cholesterol.text = food.cholesterol
            sodium.text = food.sodium
            dietaryFiber.text = food.dietary_fiber
            totalSugars.text = food.total_sugars
            protein.text = food.protein
            calcium.text = food.calcium
            iron.text = food.iron
            potassium.text = food.potassium
            healthBenefits.text = food.health_benefits
            carbs.text = food.carbs
            fat.text = food.fat
            polyunsaturated.text = food.polyunsaturated
            monounsaturated.text = food.monounsaturated
            vitaminA.text = food.vitamin_a
            vitaminC.text = food.vitamin_c
        }

        back.setOnClickListener {
            onBackPressed()
        }
    }
}
