package com.example.identifeed

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.identifeed.ui.admin.AdminViewModel
import com.example.identifeed.ui.history.HistoryViewModel
import com.example.identifeed.ui.home.HomeViewModel
import com.example.identifeed.ui.information.InformationViewModel
import com.example.identifeed.ui.profile.ProfileViewModel
import com.google.firebase.firestore.FirebaseFirestore
import java.lang.IllegalArgumentException

class ViewModelFactory : ViewModelProvider.Factory {

    //View model factory used to inject dependencies on viewmodels for this viewmodel factory no dependencies are injected
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(ProfileViewModel::class.java) -> {
                ProfileViewModel() as T
            }
            modelClass.isAssignableFrom(HistoryViewModel::class.java) -> {
                HistoryViewModel() as T
            }
            modelClass.isAssignableFrom(HomeViewModel::class.java) -> {
                HomeViewModel() as T
            }
            modelClass.isAssignableFrom(InformationViewModel::class.java) -> {
                InformationViewModel() as T
            }
            modelClass.isAssignableFrom(AdminViewModel::class.java) -> {
                AdminViewModel() as T
            }
            else -> throw IllegalArgumentException("Unknown class name!")
        }
    }

}